create definer = root@localhost trigger evenementss_insert
    before insert
    on evenements
    for each row
    SET NEW.dateC = NOW(), NEW.dateU = NOW();

