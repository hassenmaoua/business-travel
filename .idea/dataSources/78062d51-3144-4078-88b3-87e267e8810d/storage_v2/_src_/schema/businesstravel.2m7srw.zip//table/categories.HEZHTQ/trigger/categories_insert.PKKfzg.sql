create definer = root@localhost trigger categories_insert
    before insert
    on categories
    for each row
    SET NEW.dateC = NOW(), NEW.dateU = NOW();

