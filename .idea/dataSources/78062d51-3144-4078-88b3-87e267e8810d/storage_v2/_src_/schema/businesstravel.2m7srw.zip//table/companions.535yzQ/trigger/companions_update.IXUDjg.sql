create definer = root@localhost trigger companions_update
    before update
    on companions
    for each row
    SET NEW.dateU = NOW();

