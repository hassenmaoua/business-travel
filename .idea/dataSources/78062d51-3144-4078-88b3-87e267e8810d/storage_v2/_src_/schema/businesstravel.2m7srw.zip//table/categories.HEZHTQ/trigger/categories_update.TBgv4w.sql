create definer = root@localhost trigger categories_update
    before update
    on categories
    for each row
    SET NEW.dateU = NOW();

