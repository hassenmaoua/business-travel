create definer = root@localhost trigger users_insert
    before insert
    on users
    for each row
    SET NEW.dateC = NOW(), NEW.dateU = NOW();

