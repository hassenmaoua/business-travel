create definer = root@localhost trigger companions_insert
    before insert
    on companions
    for each row
    SET NEW.dateC = NOW(), NEW.dateU = NOW();

