create definer = root@localhost trigger evenementss_update
    before update
    on evenements
    for each row
    SET NEW.dateU = NOW();

