create definer = root@localhost trigger voyages_insert
    before insert
    on voyages
    for each row
    SET NEW.dateC = NOW(), NEW.dateU = NOW();

