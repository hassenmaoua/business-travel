create definer = root@localhost trigger users_update
    before update
    on users
    for each row
    SET NEW.dateU = NOW();

