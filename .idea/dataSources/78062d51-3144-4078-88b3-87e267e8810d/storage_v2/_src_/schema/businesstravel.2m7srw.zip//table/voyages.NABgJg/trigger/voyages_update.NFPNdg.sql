create definer = root@localhost trigger voyages_update
    before update
    on voyages
    for each row
    SET NEW.dateU = NOW();

