create definer = root@localhost trigger entreprises_update
    before update
    on entreprises
    for each row
    SET NEW.dateU = NOW();

