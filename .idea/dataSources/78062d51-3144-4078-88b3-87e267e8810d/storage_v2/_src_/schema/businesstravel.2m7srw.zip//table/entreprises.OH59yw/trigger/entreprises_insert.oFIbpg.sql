create definer = root@localhost trigger entreprises_insert
    before insert
    on entreprises
    for each row
    SET NEW.dateC = NOW(), NEW.dateU = NOW();

